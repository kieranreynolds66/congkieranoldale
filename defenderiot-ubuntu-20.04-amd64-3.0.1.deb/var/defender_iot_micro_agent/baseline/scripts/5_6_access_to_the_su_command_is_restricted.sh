#!/bin/bash
group=$(grep -E "^\s*auth\s+required\s+pam_wheel.so\\s+use_uid\\s+ group\\s*=" /etc/pam.d/su |cut -d "=" -f2)

if [ -z $group ]
then
        echo "pam not found"
        exit
fi
grep  $group /etc/group